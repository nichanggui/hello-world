/*
** Copyright 2012, HTC Corp.
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#ifndef ANDROID_AUDIO_UTILS_H
#define ANDROID_AUDIO_UTILS_H


#include <sys/types.h>
#include <unistd.h>

#define APP_SKYPE       "com.skype"
#define APP_SIPDROID    "org.sipdroid.sipua"
#define APP_VIBER       "com.viber"
#define APP_WECHAT      "com.tencent.mm"
#define APP_LINE        "jp.naver.line"
#define APP_HANG        "com.google.android.talk"
#define APP_TUNEIN      "tunein.service"

static inline bool audio_is_process_matched(pid_t pid, const char *name)
{
    char strProcessNamePath[255] = {0};
    char strProcessName[255] = {0};
    FILE *fid = NULL;

    if (name == NULL)
        return false;

    sprintf(strProcessNamePath, "/proc/%d/cmdline", pid);
    fid = fopen(strProcessNamePath, "r");
    if (fid) {
        fscanf(fid, "%s", strProcessName);
        fclose(fid);

        //LOGD("pid: %d name: %s", pid, strProcessName);

        if (0 == strncmp(strProcessName, name, strlen(name))) {
            return true;
        }
    }

    return false;
}



#endif  // ANDROID_AUDIO_UTILS_H
