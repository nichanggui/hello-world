/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef CAMERA_SOURCE_ZOE_H_

#define CAMERA_SOURCE_ZOE_H_

#include <pthread.h>

#include <utils/RefBase.h>
#include <utils/threads.h>

#define ENCODE_BUFFER_SLOT_NUMBER  7

namespace android {

class ICamera;
class IMemory;
class Camera;
class GraphicBuffer;
struct encoder_media_buffer_type;

class CameraSourceZoe : public CameraSource {
public:
   static CameraSourceZoe *CreateFromCamera(const sp<hardware::ICamera> &camera,
              const sp<ICameraRecordingProxy> &proxy,
              int32_t cameraId,
              const String16& clientName,
              uid_t clientUid,
              pid_t clientPid,
              Size videoSize,
              int32_t frameRate,
              const sp<IGraphicBufferProducer>& surface,
              bool storeMetaDataInVideoBuffers = false);

    // Wrapper over CameraSource::signalBufferReturned() to implement quick stop.
    // It only handles the case when mLastReadBufferCopy is signalled. Otherwise
    // it calls the base class' function.
    virtual void signalBufferReturned(MediaBuffer* buffer);

    // Wrapper over CameraSource::read() to implement quick stop.
    virtual status_t read(MediaBuffer **buffer, const ReadOptions *options = NULL);

    // In the video camera case calls skipFrameAndModifyTimeStamp() to modify
    // timestamp and set mSkipCurrentFrame.
    // Then it calls the base CameraSource::dataCallbackTimestamp()
    virtual void dataCallbackTimestamp(int64_t timestampUs, int32_t msgType,
			const sp<IMemory> &data);

    virtual void recordingFrameHandleCallbackTimestamp(int64_t timestampUs,
            native_handle_t* handle);

    virtual status_t start(MetaData *params = NULL);
    virtual status_t stop();

    //Fix me!!-Begin
    //Add an interface to monitor camera source stop status for Zoe mode
    virtual status_t notify_stop();
    //Fix me!!-End


private:

    //Fix me!!-Begin
    bool mStartedWithoutEncoding;
    uint8_t mFramesKept;
    int32_t  mNumFramesEncoding;
    bool mStartRecord;
    bool mStartRead;
    Size     mAlignedVideoSize;

    Condition mFrameAvailableCondition;
    Condition mFrameCompleteCondition;

    int64_t mNewFirstFrameTimeUs;
    int64_t mFirstFrameTimeUs;
    bool mIsZoeMode;

    List<sp<IMemory> > mFramesReceived;
    List<sp<IMemory> > mFramesBeingEncoded;
    List<int64_t> mFrameTimes;

    int mNumFramesDropped;
    int mGlitchDurationThresholdUs;
    int mNumGlitches;
    int mNumZoeFramesReceived;

    //Android N
    static const nsecs_t kMemoryBaseAvailableTimeoutNs = 200000000; // 200ms
    // Check if this frame should be skipped based on the frame's timestamp in microsecond.
    // mLock must be locked before calling this function.
    bool shouldSkipFrameLocked(int64_t timestampUs);

    //Fix me!!-End

    void releaseQueuedFrames();
    void releaseOneRecordingFrame(const sp<IMemory>& frame);

    void stopCameraRecording();

    int obtainFreeEncodeBuffer();

    CameraSourceZoe(const sp<hardware::ICamera>& camera, const sp<ICameraRecordingProxy>& proxy,
                 int32_t cameraId,
                 const String16& clientName,
                 uid_t clientUid,
                 pid_t clientPid,
                 Size videoSize, int32_t frameRate,
                 const sp<IGraphicBufferProducer>& surface,
                 bool storeMetaDataInVideoBuffers);

    CameraSourceZoe(const CameraSourceZoe &);
    CameraSourceZoe &operator=(const CameraSourceZoe &);
};

}  // namespace android

#endif  // CAMERA_SOURCE_ZOE_H_
