/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef QCP_WRITER_H_

#define QCP_WRITER_H_

#include <stdio.h>

#include <media/IMediaSource.h>
#include <media/stagefright/MediaWriter.h>
#include <utils/threads.h>

namespace android {

struct MediaSource;
struct MetaData;

//struct QCPWriter : public MediaWriter {
struct QCPWriter : public MediaWriter {
    QCPWriter(const char *filename);
    QCPWriter(int fd);

    status_t initCheck() const;

    virtual status_t addSource(const sp<IMediaSource> &source);
    virtual bool reachedEOS();
    virtual status_t start(MetaData *params = NULL);
    virtual status_t stop();
    virtual status_t pause();

protected:
    virtual ~QCPWriter();

private:
    FILE *mFile;
    status_t mInitCheck;
    sp<IMediaSource> mSource;
    bool mStarted;
    volatile bool mPaused;
    volatile bool mResumed;
    volatile bool mDone;
    volatile bool mReachedEOS;
    pthread_t mThread;
    int64_t mEstimatedSizeBytes;
    int64_t mEstimatedDurationUs;

    int16_t mBitRate;
    int32_t mTotalPackets;
    int32_t mDATAChunkSize;
    int32_t mRIFFSize;

    static void *ThreadWrapper(void *);
    status_t threadFunc();
    bool exceedsFileSizeLimit();
    bool exceedsFileDurationLimit();

    void writeHeader();
    void writeRIFFChunk();
    void writeFMTChunk();
    void writeVRATChunk();
    void writeDATAChunk();

    void filloutHeaderUndefinedInfo();
    void fillOutSizeInPackets();
    void fillOutDATAChunkSize();
    void fillOutRIFFSize();

    void writeFourcc(const char *s);
    void writeCString(const char *s);
    void writeInt8(int8_t x);
    void writeInt16(int16_t x);
    void writeInt32(int32_t x);

    QCPWriter(const QCPWriter &);
    QCPWriter &operator=(const QCPWriter &);
};

}  // namespace android

#endif  // QCP_WRITER_H_
