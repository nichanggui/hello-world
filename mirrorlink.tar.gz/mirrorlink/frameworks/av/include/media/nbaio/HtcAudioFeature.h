//HTC_AUD_START
#ifndef HTC_AUDIO_FEATURE_H
#define HTC_AUDIO_FEATURE_H

#define RAMPINGTIME 9 //second
#define DefaultValueBalance (50)
#define BalanceVolumeShift (12)
#define MaxVolumeRatioInt (1 << BalanceVolumeShift)

// range of valueBalance: 0 ~ 100
// valueBalance = 100 ==> lRatio = 0.0, rRatio = 1.0
// valueBalance =  70 ==> lRatio = 0.6, rRatio = 1.0
// valueBalance =  50 ==> lRatio = 1.0, rRatio = 1.0
// valueBalance =  30 ==> lRatio = 1.0, rRatio = 0.6
// valueBalance =   0 ==> lRatio = 1.0, rRatio = 0.0
#define LeftRatioInt(ratio)   (((ratio > 50)&&(ratio <= 100)) ? (MaxVolumeRatioInt*(100-ratio)/50) : (MaxVolumeRatioInt))
#define RightRatioInt(ratio)  (((ratio < 50)&&(ratio >= 0)) ? (MaxVolumeRatioInt*ratio/50) : (MaxVolumeRatioInt))

typedef enum acoustic_shock_event_type_t {
    ACOUSTIC_SHOCK_NORMAL = 0,//initial state,stop ramping
    ACOUSTIC_SHOCK_RAMPING = 1,//Ramping
    ACOUSTIC_SHOCK_MUTE = 2, //mute
    ACOUSTIC_SHOCK_UNMUTE = 3 //un-mute
}acoustic_shock_event_type_t;

typedef enum acoustic_state_type_t{
    ACOUSTIC_SHOCK_STATE_IDLE = 0,
    ACOUSTIC_SHOCK_STATE_RAMPING = 1,
    ACOUSTIC_SHOCK_STATE_MUTE = 2
} acoustic_state_type_t;

#define TABLE_STEP 100

int32_t get_Curren_Time();
int32_t Initial_Acoustic_Table(int* Acoustic_Table);

void applyBalanceVolume(void* inputBuf, void* outputBuf, int frameCount, int bytesPerFrame, int32_t lRatio, int32_t rRatio);
void stereo2Mono(void* inputBuf, void* outputBuf, int frameCount, int bytesPerFrame);
void acousticShockProcess(const void *buffer, size_t count, bool RampingFlag, bool MuteFlag, int32_t RampingRatio, int OutDevice, int mFormat);
void balanceAndMonoProcess(const void *buffer, size_t count, bool stereo2MonoFlag, int LeftRatioInt, int RightRatioInt, int OutDevice, int mFormat);
#endif // HTC_AUDIO_FEATURE_H
//HTC_AUD_END
