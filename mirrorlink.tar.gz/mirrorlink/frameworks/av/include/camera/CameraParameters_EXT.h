/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ANDROID_HARDWARE_CAMERA_PARAMETERS_EXT_H
#define ANDROID_HARDWARE_CAMERA_PARAMETERS_EXT_H

#include <utils/KeyedVector.h>
#include <utils/String8.h>
#include <camera/CameraParameters.h>
#include <cutils/properties.h>

namespace android {

struct Size;

#ifdef HTC_HAL_EXTENSIONS
/* HTC_START sync ics */
struct FPSRange{
    int minFPS;
    int maxFPS;

    FPSRange(){
        minFPS=0;
        maxFPS=0;
    };
    FPSRange(int min,int max){
        minFPS=min;
        maxFPS=max;
   };
};

/* HTC_END */
#endif
class CameraParameters;

class CameraParameters_EXT
{
public:

	typedef struct {
		const char *const desc;
		int val;
	} CameraMap;

	CameraParameters_EXT();
    CameraParameters_EXT(CameraParameters *mp);
    ~CameraParameters_EXT();

	int lookupAttr(const CameraMap arr[], int len, const char *name);

    const char *getPreviewFrameRateMode() const;
    void setPreviewFrameRateMode(const char *mode);

	int32_t get_from_attr(const char* item, char* buffer, int buf_size);
	bool check_flashlight_restriction();

/* HTC_START, add for flash light calibration */
    void setBrightnessLumaTargetSet(int brightness, int luma_target);
    int getBrightnessLumaTargetSet(int *brightness, int *luma_target) const;
/* HTC_END */

/* HTC_START sync ics */
    void setTouchIndexAec(int x, int y);
    void getTouchIndexAec(int *x, int *y) const;
    void setTouchIndexAf(int x, int y);
    void getTouchIndexAf(int *x, int *y) const;
    void getMeteringAreaCenter(int * x, int *y) const;
/* HTC_END */

/* HTC_START - add take raw picture feature */
    void setZsl(const char *zsl_settings);
    const char *getZsl() const;
    void setRawSize(int width, int height);
    void getRawSize(int *width, int *height) const;
/* HTC_END */
    void getSupportedHfrSizes(Vector<Size> &sizes) const;

	static const CameraMap FACE_BEAUTY_STRENGTH_MAP[];

	static const char KEY_ZOE_SUPPORTED_MODE[]; /* HTC */
	static const char KEY_ZOE_PICTURE_SIZE[]; /* HTC */
	static const char KEY_NON_ZSL_MANUAL_MODE[]; /* HTC */
	static const char KEY_ZOE_SUPPORTED_PICTURE_SIZES[]; /* HTC */
//	static const char KEY_HTC_BURSTMODE_ALWAYS[];   //HTC_ADD kevin 20140206


	//HTC_START Harvey 20130603 - Add for continue burst taking picture mode
	static const char KEY_CONTIBURST_SUPPORTED_MODE[];
	static const char KEY_CONTIBURST_AUTO[];
	static const char KEY_CONTIBURST_TAKE[];
	static const char KEY_CONTIBURST_PRETAKE[];
	//HTC_END


	//HTC_START kevin 20130729 enable fastvideo 60fps
	static const char KEY_FASTVIDEO_FPS60_SUPPORTED[];
	static const char KEY_FASTVIDEO_FPS60_1080P_SUPPORTED[];
	//HTC_END

	//HTC_START kevin 20130717 enable slow motion
	static const char KEY_SLOW_MOTION_SUPPORTED[];
	static const char KEY_SLOW_MOTION_MULTIPLE[];
	static const char KEY_SLOW_MOTION_RES[];
	static const char KEY_SLOW_MOTION_VERSION[];
	static const char KEY_VIDEO_MODE[];
	//HTC_END


    static const char KEY_PREVIEW_FRAME_RATE_MODE[];
    static const char KEY_BRIGHTNESS_LUMA_TARGET_SET[];
    //Touch Index for AEC.
    static const char KEY_TOUCH_INDEX_AEC[];
    //Touch Index for AF.
    static const char KEY_TOUCH_INDEX_AF[];
    static const char KEY_ZSL[];
/* HTC_START, add take raw picture feature */
    static const char KEY_RAW_SIZE[];
/* HTC_END */

/* HTC_START sync ics */
    // Supported PREVIEW/RECORDING SIZES IN HIGH FRAME RATE recording, sizes in pixels.
    // Example value: "800x480,432x320". Read only.
    static const char KEY_SUPPORTED_HFR_SIZES[];
/* HTC_END */
/* HTC_START sync ics */
// HTC_START sungfeng 20120515
    static const char KEY_CAPTURE_MODE[];
    static const char KEY_SUPPORTED_CAPTURE_MODES[];
// HTC_END sungfeng 20120515
// HTC_START Glenn Lin 20120807 - Burst flow control
    static const char BURST_MODE_LIMIT20[];
    static const char BURST_MODE_UNLIMITED[];
// HTC_END
/* HTC_END */

/* HTC_START sync ics */
    // The mode of preview frame rate.
    // Example value: "frame-rate-auto, frame-rate-fixed".
    static const char KEY_SUPPORTED_PREVIEW_FRAME_RATE_MODES[];
    static const char KEY_PREVIEW_FRAME_RATE_AUTO_MODE[];
    static const char KEY_PREVIEW_FRAME_RATE_FIXED_MODE[];
/* HTC_END */

/* HTC_START sync ics */
    static const char KEY_SKIN_TONE_ENHANCEMENT[] ;
    static const char KEY_SUPPORTED_SKIN_TONE_ENHANCEMENT_MODES[] ;
/* HTC_END */
/* HTC_START sync ics */
    //Touch Af/AEC settings.
    static const char KEY_TOUCH_AF_AEC[];
    static const char KEY_SUPPORTED_TOUCH_AF_AEC[];
/* HTC_END */

/* HTC_START sync ics */
    // Current auto scene detection mode.
    // Example value: "off" or SCENE_DETECT_XXX constants. Read/write.
    static const char KEY_SCENE_DETECT[];
    // Supported auto scene detection settings.
    // Example value: "off,backlight,snow/cloudy". Read only.
    static const char KEY_SUPPORTED_SCENE_DETECT[];
/* HTC_END */

/* HTC_START sync ics */
    static const char KEY_FULL_VIDEO_SNAP_SUPPORTED[];
    static const char KEY_POWER_MODE_SUPPORTED[];

    static const char KEY_ISO_MODE[];
    static const char KEY_SUPPORTED_ISO_MODES[];
    static const char KEY_LENSSHADE[] ;
    static const char KEY_SUPPORTED_LENSSHADE_MODES[] ;

    static const char KEY_AUTO_EXPOSURE[];
    static const char KEY_SUPPORTED_AUTO_EXPOSURE[];

    static const char KEY_GPS_LATITUDE_REF[];
    static const char KEY_GPS_LONGITUDE_REF[];
    static const char KEY_GPS_ALTITUDE_REF[];
    static const char KEY_GPS_STATUS[];
    static const char KEY_EXIF_DATETIME[];
/* HTC_END */

/* HTC_START sync ics */
    static const char KEY_MEMORY_COLOR_ENHANCEMENT[];
    static const char KEY_SUPPORTED_MEM_COLOR_ENHANCE_MODES[];

    static const char KEY_CONTIBURST_TYPE[]; // HTC Glenn Lin 20120807 - Burst flow control
    static const char KEY_POWER_MODE[];
    static const char KEY_SUPPORTED_ZSL_MODES[];
    static const char KEY_CAMERA_MODE[];
    static const char KEY_VIDEO_HIGH_FRAME_RATE[];
    static const char KEY_SUPPORTED_VIDEO_HIGH_FRAME_RATE_MODES[];
    static const char KEY_HIGH_DYNAMIC_RANGE_IMAGING[];
    static const char KEY_SUPPORTED_HDR_IMAGING_MODES[];
/* HTC_END */

    static const char KEY_SMILEINFO_BYFACE_SUPPORTED[];

/* HTC_START sync ics */
    static const char KEY_AE_BRACKET_HDR[];
/* HTC_END */

/* HTC_START sync ics */
    // DENOISE
	static const char KEY_DENOISE[];
    static const char KEY_SUPPORTED_DENOISE[];

    //Selectable zone AF.
    static const char KEY_SELECTABLE_ZONE_AF[];
    static const char KEY_SUPPORTED_SELECTABLE_ZONE_AF[];

    //Face Detection
    static const char KEY_FACE_DETECTION[];
    static const char KEY_SUPPORTED_FACE_DETECTION[];

    //Redeye Reduction
    static const char KEY_REDEYE_REDUCTION[];
    static const char KEY_SUPPORTED_REDEYE_REDUCTION[];

    //Values for ASD&Continue burst settings.
    static const char KEY_TIME_CONS_POST_PROCESSING[];
/* HTC_END */

/* HTC_START Horng 20121105 - OIS MODE */
	static const char KEY_OIS_MODE[];
	static const char KEY_OIS_SUPPORT[];
	static const char OIS_MODE_OFF[];
    static const char OIS_MODE_ON[];

    static const char KEY_APP_OIS_SETTING[];
    static const char APP_OIS_SETTING_TRUE[];
    static const char APP_OIS_SETTING_FALSE[];
/* HTC_END */
    static const char KEY_SAVE_MIRROR[]; //Do mirror for front cam

/* HTC_START Horng 20130527 - force use audio */
    static const char KEY_FORCE_USE_AUDIO_ENABLED[];
/* HTC_END */

/* HTC_START sync ics */
    static const char EFFECT_EMBOSS[];
    static const char EFFECT_SKETCH[];
    static const char EFFECT_NEON[];

    // Values for Touch AF/AEC
    static const char TOUCH_AF_AEC_OFF[] ;
    static const char TOUCH_AF_AEC_ON[] ;
/* HTC_END */

/* HTC_START sync ics */
	static const char SCENE_MODE_OFF[];
	static const char SCENE_MODE_BACKLIGHT[];
    static const char SCENE_MODE_FLOWERS[];
    static const char SCENE_MODE_AR[];
    static const char SCENE_MODE_TEXT[];
	static const char SCENE_MODE_EIS[]; /*HTC eis*/
	static const char SCENE_MODE_ZOE[]; /*HTC */
	static const char SCENE_MODE_PANORAMA[]; /* HTC */
	static const char SCENE_MODE_BURST[]; /* HTC */
	static const char SCENE_MODE_MANUAL[]; /* HTC */
	static const char SCENE_MODE_PANORAMA_360[]; /* HTC */
	static const char SCENE_MODE_AUTOHDR[]; /* HTC */
	static const char SCENE_MODE_AUTOHDR_BURST[]; /* HTC */

	static const char SCENE_DETECT_OFF[];
	static const char SCENE_DETECT_ON[];
/* HTC_END */

/* HTC_START sync ics */
	static const char PIXEL_FORMAT_YUV420SP_ADRENO[]; // ADRENO
	static const char PIXEL_FORMAT_RAW[];
    static const char PIXEL_FORMAT_YV12[]; // NV12
    static const char PIXEL_FORMAT_NV12[]; //NV12

// HTC_START sungfeng 20120515
    static const char CAPTURE_MODE_NORMAL[];
    static const char CAPTURE_MODE_CONTI_BURST[];
    static const char CAPTURE_MODE_HDR[];
    static const char CAPTURE_MODE_PANORAMA[];
// HTC_END sungfeng 20120515
    static const char CAPTURE_MODE_EIS[]; // HTC_START vector 2012/12/07 HTC_END
	// HTC_START Angie 20121022
	static const char CAPTURE_MODE_ZOE[];
	static const char CAPTURE_MODE_CONTI_ZOE[];
// HTC_END


/* HTC_START burst zoe - sync from chris 20120618 for burst one shot  - 20121102 */
    static const char CAPTURE_MODE_CONTI_BURST_ONE_SHOT[];
    static const char CONTI_BURST_CAPTURING[];
    static const char CONTI_BURST_CAPTURE_DONE[];
	static const char KEY_CONTI_BURST_STATE[];
/* HTC_END */

/* HTC_START sync ics */
    // Normal focus mode. Applications should call
    // CameraHardwareInterface.autoFocus to start the focus in this mode.
    static const char FOCUS_MODE_NORMAL[];
    static const char ISO_AUTO[];
    static const char ISO_HJR[] ;
    static const char ISO_100[];
    static const char ISO_200[] ;
    static const char ISO_400[];
    static const char ISO_800[];
    static const char ISO_1600[];
    // Values for Lens Shading
    static const char LENSSHADE_ENABLE[] ;
    static const char LENSSHADE_DISABLE[] ;

    // Values for auto exposure settings.
    static const char AUTO_EXPOSURE_FRAME_AVG[];
    static const char AUTO_EXPOSURE_CENTER_WEIGHTED[];
    static const char AUTO_EXPOSURE_SPOT_METERING[];

    static const char KEY_SHARPNESS[];
    static const char KEY_MAX_SHARPNESS[];
    static const char KEY_MIN_SHARPNESS[];
    static const char KEY_CONTRAST[];
    static const char KEY_MAX_CONTRAST[];
    static const char KEY_MIN_CONTRAST[];
    static const char KEY_SATURATION[];
    static const char KEY_MAX_SATURATION[];
    static const char KEY_MIN_SATURATION[];

    static const char KEY_HISTOGRAM[] ;
    static const char KEY_SUPPORTED_HISTOGRAM_MODES[] ;

    // Values for HISTOGRAM
    static const char HISTOGRAM_ENABLE[] ;
    static const char HISTOGRAM_DISABLE[] ;

    // Values for SKIN TONE ENHANCEMENT
    static const char SKIN_TONE_ENHANCEMENT_ENABLE[] ;
    static const char SKIN_TONE_ENHANCEMENT_DISABLE[] ;

    // Values for Denoise
    static const char DENOISE_OFF[] ;
    static const char DENOISE_ON[] ;

    // Values for auto exposure settings.
    static const char SELECTABLE_ZONE_AF_AUTO[];
    static const char SELECTABLE_ZONE_AF_SPOT_METERING[];
    static const char SELECTABLE_ZONE_AF_CENTER_WEIGHTED[];
    static const char SELECTABLE_ZONE_AF_FRAME_AVERAGE[];

    // Values for Face Detection settings.
    static const char FACE_DETECTION_OFF[];
    static const char FACE_DETECTION_ON[];

    // Values for MCE settings.
    static const char MCE_ENABLE[];
    static const char MCE_DISABLE[];

    // Values for ZSL settings.
    static const char ZSL_OFF[];
    static const char ZSL_ON[];

    // Values for HDR Bracketing settings.
    static const char AE_BRACKET_HDR_OFF[];
    static const char AE_BRACKET_HDR[];
    static const char AE_BRACKET[];

    // Values for Power mode settings.
    static const char LOW_POWER[];
    static const char NORMAL_POWER[];

    // Values for HFR settings.
    static const char VIDEO_HFR_OFF[];
    static const char VIDEO_HFR_2X[];
    static const char VIDEO_HFR_3X[];
    static const char VIDEO_HFR_4X[];
	static const char VIDEO_HFR_5X[];

    // Values for Redeye Reduction settings.
    static const char REDEYE_REDUCTION_ENABLE[];
    static const char REDEYE_REDUCTION_DISABLE[];
    // Values for HDR settings.
    static const char HDR_ENABLE[];
    static const char HDR_DISABLE[];

    // Values for ASD&Continue burst settings.
    static const char POST_PROCESSING_ENABLE[];
    static const char POST_PROCESSING_BYPASS[];
    static const char POST_PROCESSING_DELAY[];

   // Values for Redeye Reduction settings.
   // static const char REDEYE_REDUCTION_ENABLE[];
   // static const char REDEYE_REDUCTION_DISABLE[];
   // Values for HDR settings.
   //    static const char HDR_ENABLE[];
   //    static const char HDR_DISABLE[];

    static const char KEY_SINGLE_ISP_OUTPUT_ENABLED[];

    enum {
        CAMERA_ORIENTATION_UNKNOWN = 0,
        CAMERA_ORIENTATION_PORTRAIT = 1,
        CAMERA_ORIENTATION_LANDSCAPE = 2,
    };
    int getOrientation() const;
    void setOrientation(int orientation);
    void setPreviewFpsRange(int minFPS,int maxFPS);
/* HTC_END */

private:
	CameraParameters *m_p;
};

}; // namespace android

#endif
