/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define LOG_NDEBUG 0
#define LOG_TAG "DrmMirrorLinkPlugIn"
#include <utils/Log.h>
#include <dlfcn.h>

#include <drm/DrmRights.h>
#include <drm/DrmConstraints.h>
#include <drm/DrmMetadata.h>
#include <drm/DrmInfo.h>
#include <drm/DrmInfoEvent.h>
#include <drm/DrmInfoStatus.h>
#include <drm/DrmConvertedStatus.h>
#include <drm/DrmInfoRequest.h>
#include <drm/DrmSupportInfo.h>
#include <DrmMirrorLinkPlugIn.h>

using namespace android;

#define TPM_LIBRARY "libdaptpm.so"
#define CERT_LIBRARY "libdapcert.so"

#define DRM_COMMAND_READ_PCR10 						0
#define DRM_COMMAND_EXTEND_PCR10 					1
#define DRM_COMMAND_GET_QUOTEINFO 					2
#define DRM_COMMAND_SIGN_QUOTEINFO 					3
#define DRM_COMMAND_GET_MFG_CERT_COUNT				4
#define DRM_COMMAND_GET_DEVICE_CERT					5
#define DRM_COMMAND_GET_MFG_CERT_BY_INDEX			6

#define MFG_CERT_MAX_SIZE							(6 * 1024)
#define MFG_CERT_HEAD_SIZE							8
#define HASH_SIZE									20
#define QUOTE_INFO_SIZE								48
#define QUOTE_INFO_SIG_SIZE							256


static char *manufacturerCertsBuffer = NULL;
static int manufacturerCertCount = 0;

static void *tpmLibHandle = NULL;
static uint8_t *(*TPM_PCR10_Read)(void) = NULL;
static uint8_t *(*TPM_PCR10_Extend)(uint8_t *digest) = NULL;
static uint8_t *(*TPM_PCR10_QuoteInfoStruct)(uint8_t *digest) = NULL;
static uint8_t *(*TPM_QuoteSignature)(uint8_t *quoteInfo) = NULL;

static void *certLibHandle = NULL;
static int (*getMFGCert)(char *buffer, int input_buffer_length) = NULL;
static int (*getMFGCertMulti)(char *buffer, int input_buffer_length, int *count) = NULL;
static int (*getDevCert)(char *buffer, int input_buffer_length) = NULL;

// This extern "C" is mandatory to be managed by TPlugInManager
extern "C" IDrmEngine* create() {
    tpmLibHandle = dlopen(TPM_LIBRARY, RTLD_NOW);
    char *error = NULL;

    if (tpmLibHandle != NULL) {
        // Clear any existing error
        dlerror(); 
        
        TPM_PCR10_Read = (uint8_t *(*)(void))dlsym(tpmLibHandle, "TPM_PCR10_Read");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

        TPM_PCR10_Extend = (uint8_t *(*)(uint8_t *))dlsym(tpmLibHandle, "TPM_PCR10_Extend");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

        TPM_PCR10_QuoteInfoStruct = (uint8_t *(*)(uint8_t *))dlsym(tpmLibHandle, "TPM_PCR10_QuoteInfoStruct");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

        TPM_QuoteSignature = (uint8_t *(*)(uint8_t *))dlsym(tpmLibHandle, "TPM_QuoteSignature");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

    } else {
        ALOGE("%s", dlerror());
    }

    certLibHandle = dlopen(CERT_LIBRARY, RTLD_NOW);
    if (certLibHandle != NULL) {
        dlerror();

        getMFGCert = (int (*)(char *, int))dlsym(certLibHandle, "getMFGCert");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

        getMFGCertMulti = (int (*)(char *, int, int*))dlsym(certLibHandle, "getMFGCertMulti");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);

        getDevCert = (int (*)(char *, int))dlsym(certLibHandle, "getDevCert");
        if ((error = (char *)dlerror()) != NULL)
            ALOGE("%s", error);
    } else {
        ALOGE("%s", dlerror());
    }

    return new DrmMirrorLinkPlugIn();
}

// This extern "C" is mandatory to be managed by TPlugInManager
extern "C" void destroy(IDrmEngine* pPlugIn) {
    if (tpmLibHandle) {
        dlclose(tpmLibHandle);
        tpmLibHandle = NULL;
    }

    if (certLibHandle) {
        dlclose(certLibHandle);
        certLibHandle = NULL;
    }        

    delete pPlugIn;
    pPlugIn = NULL;
}

DrmMirrorLinkPlugIn::DrmMirrorLinkPlugIn()
    : DrmEngineBase() {
    if (manufacturerCertsBuffer == NULL && getMFGCertMulti) {
    	manufacturerCertsBuffer = new char[MFG_CERT_MAX_SIZE];
		if (manufacturerCertsBuffer != NULL)
			getMFGCertMulti(manufacturerCertsBuffer, MFG_CERT_MAX_SIZE, &manufacturerCertCount);
    }
}

DrmMirrorLinkPlugIn::~DrmMirrorLinkPlugIn() {
    if (manufacturerCertsBuffer != NULL) {
    	delete[] manufacturerCertsBuffer;
    	manufacturerCertsBuffer = NULL;
    }
}

DrmMetadata* DrmMirrorLinkPlugIn::onGetMetadata(int uniqueId, const String8* path) {
    return NULL;
}

DrmConstraints* DrmMirrorLinkPlugIn::onGetConstraints(
        int uniqueId, const String8* path, int action) {
    DrmConstraints* drmConstraints = new DrmConstraints();
    return drmConstraints;
}

DrmInfoStatus* DrmMirrorLinkPlugIn::onProcessDrmInfo(int uniqueId, const DrmInfo* drmInfo) {
    DrmInfoStatus* drmInfoStatus = NULL;
    return drmInfoStatus;
}

status_t DrmMirrorLinkPlugIn::onSetOnInfoListener(
            int uniqueId, const IDrmEngine::OnInfoListener* infoListener) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onInitialize(int uniqueId) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onTerminate(int uniqueId) {
    return DRM_NO_ERROR;
}

DrmSupportInfo* DrmMirrorLinkPlugIn::onGetSupportInfo(int uniqueId) {
    ALOGV("onGetSupportInfo : %d", uniqueId);
    DrmSupportInfo* drmSupportInfo = new DrmSupportInfo();
    // Add mimetype's
    drmSupportInfo->addMimeType(String8("application/mirrorlink.drm"));
    // Add File Suffixes
    drmSupportInfo->addFileSuffix(String8(".mirrorlink"));
    // Add plug-in description
    drmSupportInfo->setDescription(String8("MirrorLink plug-in"));
    return drmSupportInfo;
}

status_t DrmMirrorLinkPlugIn::onSaveRights(int uniqueId, const DrmRights& drmRights,
            const String8& rightsPath, const String8& contentPath) {
    return DRM_NO_ERROR;
}

DrmInfo* DrmMirrorLinkPlugIn::onAcquireDrmInfo(int uniqueId, const DrmInfoRequest* drmInfoRequest) {
    ALOGV("onAcquireDrmInfo : %d", uniqueId);
    DrmInfo* drmInfo = NULL;
    return drmInfo;
}

bool DrmMirrorLinkPlugIn::onCanHandle(int uniqueId, const String8& path) {
    return false;
}

String8 DrmMirrorLinkPlugIn::onGetOriginalMimeType(int uniqueId, const String8& path, int fd) {
    return String8("application/mirrorlink");
}

int DrmMirrorLinkPlugIn::onGetDrmObjectType(
            int uniqueId, const String8& path, const String8& mimeType) {
    return DrmObjectType::UNKNOWN;
}

int DrmMirrorLinkPlugIn::onCheckRightsStatus(int uniqueId, const String8& path, int action) {
    int rightsStatus = RightsStatus::RIGHTS_VALID;
    return rightsStatus;
}

status_t DrmMirrorLinkPlugIn::onConsumeRights(int uniqueId, DecryptHandle* decryptHandle,
            int action, bool reserve) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onSetPlaybackStatus(int uniqueId, DecryptHandle* decryptHandle,
            int playbackStatus, int64_t position) {
    return DRM_NO_ERROR;
}

bool DrmMirrorLinkPlugIn::onValidateAction(int uniqueId, const String8& path,
            int action, const ActionDescription& description) {
    return true;
}

status_t DrmMirrorLinkPlugIn::onRemoveRights(int uniqueId, const String8& path) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onRemoveAllRights(int uniqueId) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onOpenConvertSession(int uniqueId, int convertId) {
    ALOGV("onOpenConvertSession() : %d", uniqueId);
    return DRM_NO_ERROR;
}

DrmConvertedStatus* DrmMirrorLinkPlugIn::onConvertData(
            int uniqueId, int convertId, const DrmBuffer* inputData) {
    ALOGV("onConvertData() : %d", uniqueId);
    DrmBuffer* convertedData = NULL;

    if (NULL != inputData && 0 < inputData->length) {
    	int length = 0;
    	char *data = NULL;
    	char *temp = NULL;

    	ALOGV("onConvertData() : command=%d", inputData->data[0]);
    	switch (inputData->data[0]) {
    	case DRM_COMMAND_READ_PCR10:
    		ALOGV("Read PCR10");
    		length = HASH_SIZE;
    		data = new char[length];
                if (TPM_PCR10_Read)
       		    memcpy(data, TPM_PCR10_Read(), length);
    		break;

    	case DRM_COMMAND_EXTEND_PCR10:
    		ALOGV("Extend PCR10");
    		length = HASH_SIZE;
    		data = new char[length];
                if (TPM_PCR10_Extend)
    		    memcpy(data, TPM_PCR10_Extend((unsigned char *)&inputData->data[1]), length);
    		break;

    	case DRM_COMMAND_GET_QUOTEINFO:
    		ALOGV("Get QuoteInfoStruct");
    		length = QUOTE_INFO_SIZE;
    		data = new char[length];
                if (TPM_PCR10_QuoteInfoStruct)
    		    memcpy(data, TPM_PCR10_QuoteInfoStruct((unsigned char *)&inputData->data[1]), length);
    		break;

    	case DRM_COMMAND_SIGN_QUOTEINFO:
    		ALOGV("Sign QuoteInfoStruct");
    		length = QUOTE_INFO_SIG_SIZE;
    		data = new char[length];
                if (TPM_QuoteSignature)
    		    memcpy(data, TPM_QuoteSignature((unsigned char *)&inputData->data[1]), length);
    		break;

    	case DRM_COMMAND_GET_MFG_CERT_COUNT:
    		ALOGV("Get Manufacturer cert count: %d", manufacturerCertCount);
    		length = 1;
    		data = new char[length];
   			data[0] = (char)manufacturerCertCount;
    		break;

    	case DRM_COMMAND_GET_DEVICE_CERT:
    		ALOGV("Get device cert");
    		temp = new char[MFG_CERT_MAX_SIZE];
    		if (temp != NULL && getDevCert && (length = getDevCert(temp, MFG_CERT_MAX_SIZE)) > 0) {
    			data = new char[length];
    			memcpy(data, temp, length);
    		}

    		if (temp != NULL)
    			delete[] temp;
    		break;

    	case DRM_COMMAND_GET_MFG_CERT_BY_INDEX:
    		ALOGV("Get manufacturer cert %d", inputData->data[1]);
    		char *p = manufacturerCertsBuffer;
    		int index = inputData->data[1];
    		int pos = 0;
    		while (p != NULL) {
    			length = *((int *)p);
    			if (pos++ == index) {
    				data = new char[length];
    				if (data != NULL) {
    					memcpy(data, p + MFG_CERT_HEAD_SIZE, length);
    					break;
    				}
    			}
    			p += (length + MFG_CERT_HEAD_SIZE);
    		}
    		break;
    	}

        convertedData = new DrmBuffer(data, length);
    }
    return new DrmConvertedStatus(DrmConvertedStatus::STATUS_OK, convertedData, 0 /*offset*/);
}

DrmConvertedStatus* DrmMirrorLinkPlugIn::onCloseConvertSession(int uniqueId, int convertId) {
    ALOGV("onCloseConvertSession() : %d", uniqueId);
    return new DrmConvertedStatus(DrmConvertedStatus::STATUS_OK, NULL, 0 /*offset*/);
}

status_t DrmMirrorLinkPlugIn::onOpenDecryptSession(
            int uniqueId, DecryptHandle* decryptHandle, int fd, off64_t offset, off64_t length) {
    return DRM_ERROR_CANNOT_HANDLE;
}

status_t DrmMirrorLinkPlugIn::onOpenDecryptSession(
            int uniqueId, DecryptHandle* decryptHandle, const char* uri) {
    return DRM_ERROR_CANNOT_HANDLE;
}

status_t DrmMirrorLinkPlugIn::onCloseDecryptSession(int uniqueId, DecryptHandle* decryptHandle) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onInitializeDecryptUnit(int uniqueId, DecryptHandle* decryptHandle,
            int decryptUnitId, const DrmBuffer* headerInfo) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onDecrypt(int uniqueId, DecryptHandle* decryptHandle,
            int decryptUnitId, const DrmBuffer* encBuffer, DrmBuffer** decBuffer, DrmBuffer* IV) {
    return DRM_NO_ERROR;
}

status_t DrmMirrorLinkPlugIn::onFinalizeDecryptUnit(
            int uniqueId, DecryptHandle* decryptHandle, int decryptUnitId) {
    return DRM_NO_ERROR;
}

ssize_t DrmMirrorLinkPlugIn::onPread(int uniqueId, DecryptHandle* decryptHandle,
            void* buffer, ssize_t numBytes, off64_t offset) {
    return 0;
}

