package com.example.tttt;

import android.app.Activity;
import android.hardware.input.InputManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.MotionEvent.PointerCoords;
import android.view.MotionEvent.PointerProperties;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.android.commands.input.Input;

public class MultitouchActivity2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		findViewById(R.id.go).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.i("key", "button onclick!!!");

				multitouch.sendEmptyMessage(1);
			}
		});
	}

@Override
public boolean onTouchEvent(MotionEvent event) {
	    	Toast.makeText(this, "onTouch: action: " +event.getAction(), Toast.LENGTH_LONG).show();
		Log.i("key", event + " x:" + event.getRawX() + "   > " + " action: " + event.getAction() + "&"
				+ event.ACTION_MASK + "=" + (event.getAction() & event.ACTION_MASK));

		return true;
}

	// @Override
	// public boolean onTouch(View v, MotionEvent event) {
	// Toast.makeText(this, "onTouch: action: " +event.getAction(),
	// Toast.LENGTH_LONG).show();
	// Log.i("key", event + " x:" + event.getRawX() + " > " + " action: "
	// +event.getAction() + "&"+event.ACTION_MASK + "=" + (event.getAction() &
	// event.ACTION_MASK) );
	//
	// return true;
	// }

	private Handler multitouch = new Handler() {
		public void handleMessage(android.os.Message msg) {
			String[] args = {"tap","200","300"};
			Input.main(args);


			// down
			PointerProperties[] po = { new PointerProperties() };
			PointerCoords p11 = new PointerCoords();
			p11.clear();
			p11.x = 200.0f;
			p11.y = msg.what + 20.0f;
			p11.pressure = 1.0f;
			p11.size = 1.0f;
			PointerCoords[] pp = { p11 };
			MotionEvent down1 = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
					MotionEvent.ACTION_DOWN, 1, po, pp, 0, 0, 1.0f, 1.0f, 0, 0, 0, 0);
			//dispatchTouchEvent(down);
			MotionEvent down = MotionEvent.obtain(MotionEvent.obtain(SystemClock.uptimeMillis(),
					SystemClock.uptimeMillis(), MotionEvent.ACTION_DOWN, 200, msg.what + 20, 0));
			Log.i("key", "Handler  multitouch !!!");
			//InputManager.getInstance().injectInputEvent(down,
			 //     InputManager.INJECT_INPUT_EVENT_MODE_WAIT_FOR_FINISH);
			Log.i("key", "Handler  multitouch 11111111111111111!!!");
			//InputManager.getInstance().injectInputEvent(down1,
			//      InputManager.INJECT_INPUT_EVENT_MODE_WAIT_FOR_FINISH);

			// move
			MotionEvent downMove = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
					MotionEvent.ACTION_MOVE, 1, po, pp, 0, 0, 1.0f, 1.0f, 0, 0, 0, 0);
			// dispatchTouchEvent(downMove);

			// point_down
			PointerCoords p1 = new PointerCoords();
			p1.clear();
			p1.x = 200.0f;
			p1.y = msg.what + 20.0f;
			p1.pressure = 1.0f;
			p1.size = 1.0f;
			PointerCoords p2 = new PointerCoords();
			p2.clear();
			p2.x = 220.0f;
			p2.y = msg.what + 40.0f;
			p2.pressure = 1.0f;
			p2.size = 1.0f;

			PointerCoords[] pointerCoords = { p1, p2 };
			PointerProperties[] pointerProperties = new PointerProperties[2];
			PointerProperties pp1 = new PointerProperties();
			pp1.id = 0;
			PointerProperties pp2 = new PointerProperties();
			pp2.id = 1;
			pointerProperties[0] = pp1;
			pointerProperties[1] = pp2;
			MotionEvent pointDown = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
					MotionEvent.ACTION_POINTER_DOWN, 2, pointerProperties, pointerCoords, 0, 0, 1.0f, 1.0f, 0, 0, 0, 0);
			// dispatchTouchEvent(pointDown);

			// point_up
			MotionEvent pointUP = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
					MotionEvent.ACTION_POINTER_UP, 2, pointerProperties, pointerCoords, 0, 0, 1.0f, 1.0f, 0, 0, 0, 0);
			// dispatchTouchEvent(pointUP);

			// up
			MotionEvent up = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
					MotionEvent.ACTION_UP, 1, po, pp, 0, 0, 1.0f, 1.0f, 0, 0, 0, 0);
			// dispatchTouchEvent(up);

			Message msgs = Message.obtain();
			msgs.what = msg.what + 50;
			msgs.obj = "input tap 100 ";
			multitouch.sendMessageDelayed(msgs, 2000);
		}
	};

}
